#include <ctype.h>
#include <math.h>
#include <memory.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

double bisection_meth(double x0, double x1, double eps, double (*func)(double))
{
    double res0 = (*func)(x0);
    double res1 = (*func)(x1);
    double pivot;

    printf("=== Bisection Method ===\n");
    printf("Initial values: x0 = %lf, f(x0) = %lf | x1 = %lf, f(x1) = %lf\n", x0, res0, x1, res1);
    if (fabs(res0) <= eps)
    {
        printf("f(x0) is within tolerance, returning x0 = %lf\n", x0);
        return x0;
    }
    else if (fabs(res1) <= eps)
    {
        printf("f(x1) is within tolerance, returning x1 = %lf\n", x1);
        return x1;
    }
    else if (res0 * res1 >= 0)
    {
        printf("ERROR: Cannot detect a root between the intervals! (f(a) * f(b) is equal or bigger than 0)\n");
        return __INT64_MAX__ + 1;
    }
    do
    {
        pivot = (x0 + x1) / 2.0;
        double t = (*func)(pivot);
        if (t * res0 < 0)
            x1 = pivot;
        else if (t * res1 < 0)
        {
            x0 = pivot;
        }
        else
        {
            return pivot;
        }
        res0 = (*func)(x0);
        res1 = (*func)(x1);
        printf("x0: %lf (%lf) x1: %lf (%lf) pivot: %lf (%lf)\n", x0, res0, x1, res1, pivot, t);
    } while (fabs(x0 - x1) > eps);
    return pivot;
}

double regula_falsi(double x0, double x1, double eps, double (*func)(double))
{
    double res0 = (*func)(x0);
    double res1 = (*func)(x1);

    printf("=== Regula Falsi Method ===\n");
    printf("Initial values: x0 = %lf, f(x0) = %lf | x1 = %lf, f(x1) = %lf\n", x0, res0, x1, res1);

    if (fabs(res0) <= eps)
    {
        printf("f(x0) is within tolerance, returning x0 = %lf\n", x0);
        return x0;
    }
    else if (fabs(res1) <= eps)
    {
        printf("f(x1) is within tolerance, returning x1 = %lf\n", x1);
        return x1;
    }
    else if (res0 * res1 >= 0)
    {
        printf("ERROR: Cannot detect a root between the intervals! (f(a) * f(b) is equal or bigger than 0)");
        return __INT64_MAX__ + 1;
    }
    double pos;
    double res;

    unsigned iteration = 0;
    do
    {
        pos = (x0 * res1 - x1 * res0)/(res1 - res0);
        res = (*func)(pos);

        printf("Iteration %d:\n", ++iteration);
        printf("  pos = %lf | f(pos) = %lf\n", pos, res);
        printf("  Interval: [x0 = %lf, f(x0) = %lf], [x1 = %lf, f(x1) = %lf]\n", x0, res0, x1, res1);

        if(res * res0 < 0){
            x1 = pos;
            res1 = res;
            printf("  New x1 = %lf (root is between x0 and pos)\n", x1);
        }else{
            x0 = pos;
            res0 = res;
            printf("  New x0 = %lf (root is between pos and x1)\n", x0);
        }
    } while (fabs(res) > eps);
    printf("=== Converged: root ≈ %lf (|f(root)| = %lf) ===\n", pos, fabs(res));
    return pos;
}
// Using the derivative of f(x) we can find the solution
// By approaching to the answer

// Formula: 
//          x1 = x0 - ( f(x0) / f'(x0) )
// Return: 
//          x1 if f(x1) < eps
double newton_raphton(double x, double eps, double (*func)(double), double (*deriv_func)(double)){
    double res = (*func)(x);
    if(fabs(res) <= eps){
        return x;
    }
    unsigned iterations = 0;
    do
    {
        iterations++;
        printf("BEFORE:\tx: (%lf) f(x): %lf f'(x): %lf\n", x, res, (*deriv_func)(x));
        x = x - res/(*deriv_func)(x);
        res = (*func)(x);
        printf("AFTER:\tx: (%lf) f(x): %lf f'(x): %lf\n", x, res, (*deriv_func)(x));
    } while (fabs(res) > eps);
    printf("Iterations: %u\n\n", iterations);
    return x;
}

double newton_raphton_debug(double x, double eps, double (*func)(double), double (*deriv_func)(double)){
    unsigned iterations = 0;
    double res = (*func)(x);
    if(fabs(res) <= eps){
        return x;
    }
    do
    {
        iterations++;
        printf("BEFORE:\tx: (%lf) f(x): %lf f'(x): %lf\n", x, res, (*deriv_func)(x));
        x = x - res/(*deriv_func)(x);
        res = (*func)(x);
        printf("AFTER:\tx: (%lf) f(x): %lf f'(x): %lf\n", x, res, (*deriv_func)(x));
    } while (fabs(res) > eps);
    printf("Iterations: %u\n\n", iterations);
    return x;
}

#ifndef MATRIX_H
#define MATRIX_H

typedef struct sMat{
    double **data;
    unsigned rows;
    unsigned cols;
} Matrix;

int ipow(int num, unsigned pow){
    int res = 1;
    while(pow-- > 0) res*=num;
    return res;
}

void fswap(double *x, double *y){
    double t = *x;
    *x = *y;
    *y = t;
}

void swap(int *x, int *y){
    int t = *x;
    *x = *y;
    *y = t;
}

Matrix swapRows(Matrix mat, unsigned row1, unsigned row2){
    if(row1 >= mat.rows || row2 >= mat.rows){
        printf("Row index exceding boundaries when swapping! Empty matrix returned\n");
        return (Matrix){
            .cols = 0,
            .rows = 0,
            .data = NULL
        };
    }
    
    for (size_t i = 0; i < mat.cols; i++)
        fswap(&mat.data[row1][i], &mat.data[row2][i]);
    return mat;
} 

Matrix initMatrix(unsigned row, unsigned col){
    Matrix mat;
    mat.data = malloc(sizeof(double*) * row);
    for (size_t i = 0; i < row; i++)
    {
        mat.data[i] = calloc(col, sizeof(double));
    }
    unsigned *ref = &mat.rows; 
    *ref = row;
    ref = &mat.cols;
    *ref = col;
    return mat;
}

void setDataMatrix(Matrix mat, double *data){
    for (size_t i = 0; i < mat.rows; i++)
        for (size_t j = 0; j < mat.cols; j++)
            mat.data[i][j] = data[(i * mat.cols) + j];
}

void freeMatrix(Matrix mat){
    for (size_t i = 0; i < mat.rows; i++)
        free(mat.data[i]);
    free(mat.data);
}

void printMatrix(Matrix mat){
    for (size_t i = 0; i < mat.rows; i++)
    {
        printf("| ");
        for (size_t j = 0; j < mat.cols; j++)
            printf("%.3lf ", mat.data[i][j]);
        printf("\t|\n");
    }
    printf("\n");
}

Matrix copyMatrix(Matrix mat){
    Matrix ret = initMatrix(mat.rows, mat.cols);
    for (size_t i = 0; i < mat.rows; i++)
        for (size_t j = 0; j < mat.cols; j++)
            ret.data[i][j] = mat.data[i][j];
    return ret;
}

void scalarMultiply(Matrix mat, double num){
    for (size_t i = 0; i < mat.rows; i++)
        for (size_t j = 0; j < mat.cols; j++)
            mat.data[i][j] *= num;
}

void scalarDivide(Matrix mat, double num){
    for (size_t i = 0; i < mat.rows; i++)
        for (size_t j = 0; j < mat.cols; j++)
            mat.data[i][j] /= num;
}

Matrix add(Matrix mat1, Matrix mat2){
    if(mat1.data == NULL || mat2.data == NULL || mat1.rows != mat2.rows || mat1.cols != mat2.cols){
        printf("WARNING: data == NULL OR dimensions mismatch for add() => Empty matrix returned!\n");
        return (Matrix){.rows = 0, .cols = 0, .data = NULL};
    }
    Matrix ret = copyMatrix(mat1);
    for (size_t i = 0; i < mat1.rows; i++)
        for (size_t j = 0; j < mat1.cols; j++)
            ret.data[i][j] += mat2.data[i][j];
    return ret;
}

Matrix subtract(Matrix mat1, Matrix mat2){
    if(mat1.data == NULL || mat2.data == NULL || mat1.rows != mat2.rows || mat1.cols != mat2.cols){
        printf("WARNING: data == NULL OR dimensions mismatch for subtract() => Empty matrix returned!\n");
        return (Matrix){.rows = 0, .cols = 0, .data = NULL};
    }
    Matrix ret = copyMatrix(mat1);
    for (size_t i = 0; i < mat1.rows; i++)
        for (size_t j = 0; j < mat1.cols; j++)
            ret.data[i][j] -= mat2.data[i][j];
    return ret;
}

Matrix multiply(Matrix mat1, Matrix mat2){
    if(mat1.cols != mat2.rows){
        printf("WARNING: dimensions mismatch for multiply() => Empty matrix returned!\n");
        return (Matrix){.rows = 0, .cols = 0, .data = NULL};
    }
    Matrix ret = initMatrix(mat1.rows, mat2.cols);
    double res = 0.0;
    for (size_t y = 0; y < ret.rows; y++)
    {
        for (size_t x = 0; x < ret.cols; x++)
        {
            res = 0.0;
            for (size_t i = 0; i < mat1.cols; i++)
                res += mat1.data[y][i] * mat2.data[i][x];
            ret.data[y][x] = res;
        }

    }
    return ret;
}

Matrix transpose(Matrix mat){
    Matrix ret_mat = initMatrix(mat.cols, mat.rows);
    for (size_t i = 0; i < mat.rows; i++)
        for (size_t j = 0; j < mat.cols; j++)
            ret_mat.data[j][i] = mat.data[i][j];
    return ret_mat;
}

Matrix submat(Matrix mat, unsigned i, unsigned j){
    if (i >= mat.rows || j >= mat.cols || mat.data == NULL) {
        fprintf(stderr, "WARNING: submat indices out of range! (%u,%u) in %ux%u\n", i, j, mat.rows, mat.cols);
        return (Matrix){0,0,NULL};
    }
    Matrix ret = initMatrix(mat.rows - 1, mat.cols - 1);
    unsigned y = 0, x;
    for (unsigned ii = 0; ii < mat.rows; ii++) {
        if (ii == i) continue;
        x = 0;
        for (unsigned jj = 0; jj < mat.cols; jj++) {
            if (jj == j) continue;
            ret.data[y][x++] = mat.data[ii][jj];
        }
        y++;
    }
    return ret;
}

double determinant(Matrix mat){
    if(mat.cols != mat.rows){
        printf("WARNING: rows != columns for determinant() => Overflow returned\n");
        return __INT64_MAX__ + 1;
    }
    if (mat.cols == 1) {
        return mat.data[0][0];
    }
    if(mat.cols == 2){
        return (mat.data[0][0] * mat.data[1][1]) - (mat.data[0][1] * mat.data[1][0]);
    }
    double res = 0.0f;
    for (size_t j = 0; j < mat.cols; j++)
    {
        Matrix sub = submat(mat, 0, j);
        res += ipow(-1, j) * mat.data[0][j] * determinant(sub);
        freeMatrix(sub);
    }
    return res;
}

Matrix cofactor(Matrix mat){
    Matrix ret = initMatrix(mat.rows, mat.cols);
    for (size_t i = 0; i < mat.rows; i++)
    {
        for (size_t j = 0; j < mat.cols; j++)
        {
            Matrix sub = submat(mat, i, j);
            ret.data[i][j] = ipow(-1, i+j) * determinant(sub);
            freeMatrix(sub);
        }   
    }
    return ret;
}

Matrix adjoint(Matrix mat){
    Matrix cof = cofactor(mat);
    Matrix ret = transpose(cof);
    freeMatrix(cof);
    return ret;
}

Matrix inverse(Matrix mat){
    Matrix adj = adjoint(mat);
    printf("Adjoint:\n");
    printMatrix(adj);
    double deter = determinant(mat);
    printf("Determinant: %lf\n", deter);
    scalarDivide(adj, deter);
    return adj;
}

#endif

double trapezoidal_integration(double a, double b, unsigned rects, double (*func)(double)){
    double width = fabs(b - a) / (double)rects;
    double result = 0.0;
    printf("a = %lf, b = %lf, rects = %u, width = %lf\n", a, b, rects, width);
    for (size_t i = 1; i <= rects; i++)
    {
        double x0 = a + width * (double)(i - 1);
        double x1 = a + width * (double)i;

        double h0 = (*func)(x0);
        double h1 = (*func)(x1);

        double area = 0.5 * width * (h0 + h1);
        result += 0.5f * width * (h0 + h1);
         printf("i = %zu | x0 = %lf, h0 = %lf | x1 = %lf, h1 = %lf | area = %lf | result = %lf\n", i, x0, h0, x1, h1, area, result);
    }
    return result;
}

double trapezoidal_integration_debug(double a, double b, unsigned rects, double (*func)(double)){
    double width = fabs(b - a) / (double)rects;
    printf("WIDTH: %lf\n", width);
    double result = 0.0;
    for (size_t i = 1; i <= rects; i++)
    {

        double h0 = (*func)(a + (width * (double)(i - 1)));
        double h1 = (*func)(a + (width * (double)(i)));
        result += 0.5f * width * (h0 + h1);
        printf("h0: %lf\th1:%lf\tres:%lf\n", h0, h1, result);
        
    }
    return result;
}

double trapezoidal_integration_improved(double a, double b, unsigned rects, double (*func)(double)){
    double width = fabs(b - a) / (double)rects;
    double result = 0.0;
    for (size_t i = 1; i <= rects - 1; i++)
    {
        result += (*func)(a + (width * (double)i));
    }
    double h0 = (*func)(a);
    double hn = (*func)(a + (width * (double)(rects)));
    result = (result + (h0 + hn) * 0.5) * width;
    return result;
}

double trapezoidal_integration_improved_debug(double a, double b, unsigned rects, double (*func)(double)){
    double width = fabs(b - a) / (double)rects;
    printf("WIDTH: %lf\n", width);
    double result = 0.0;
    for (size_t i = 1; i <= rects - 1; i++)
    {
        double value = (*func)(a + (width * (double)i));
        result += value;
        printf("result: %lf\tvalue:%lf\n", result, value);
    }
    double h0 = (*func)(a);
    double hn = (*func)(a + (width * (double)(rects)));
    result = (result + (h0 + hn) * 0.5) * width;
    printf("h0: %lf\thn:%lf\tres:%lf\n", h0, hn, result);
    return result;
}
#ifndef INTEG_SIMPSON_H
#define INTEG_SIMPSON_H

double simpson_1_3_integration(double a, double b, const unsigned rects, double (*func)(double)){
    double h = fabs(b - a)/rects;
    double res = 0.0;
    double left = (a < b) ? a : b;
    printf("Simpson 1/3 -> a = %lf, b = %lf, rects = %u, h = %lf\n", a, b, rects, h);
    for (size_t i = 0; i < rects + 1; i++)
    {
        double x = left + i * h;
        double fx = (*func)(x);
        printf("i = %zu | x = %lf | f(x) = %lf | partial sum = %lf\n", i, x, fx, res);
        if(i == 0 || i == rects){
            res += fx;
        }else if(i % 2 == 0){
            res += 2 * fx;
        }else{
            res += 4 * fx;
        }
    }
    res *= h/3.0;
    printf("Final result before abs: %lf\n", res);
    return (res < 0) ? -res : res;
}

double simpson_3_8_integration(double a, double b, const unsigned n, double (*func)(double)) {
    // n must be a multiple of 3
    if (n % 3 != 0) {
        printf("simpson_3_8_integration error: n must be multiple of 3 (you passed %u)\n", n);
        return __INT64_MAX__ + 1;
    }
    double h = (b - a) / (double)n;
    double sum = func(a) + func(b);

    // Sum over interior points
    for (unsigned i = 1; i < n; i++) {
        double x = a + i*h;
        // if i mod 3 == 0: coefficient 2; else: coefficient 3
        sum += ((i % 3 == 0) ? 2.0 : 3.0) * func(x);
    }

    return (3.0*h/8.0) * sum;
}
#endif

double back_diff_derivative(double x, double eps, double (*func)(double)){
    // ((*func)(x) - (*func)(x - eps)) / (x - (x - eps));
    return ((*func)(x) - (*func)(x - eps)) / (eps);
}

double front_diff_derivative(double x, double eps, double (*func)(double)){
    // ((*func)(x) - (*func)(x + eps)) / (x - (x + eps));
    return ((*func)(x + eps) - (*func)(x)) / (eps);
}

double central_diff_derivative(double x, double eps, double (*func)(double)){
    return ((*func)(x + eps) - (*func)(x - eps)) / (2.0 * eps);
}

#ifndef GAUSS_SEIDAL_H
#define GAUSS_SEIDAL_H

Matrix gauss_seidal(const Matrix equations, const Matrix constants, double eps){
    Matrix *matrices;
    Matrix solutions = initMatrix(equations.rows, 1);
    double *deltas;
    double *biggers;

    Matrix copy_eque = copyMatrix(equations);
    Matrix copy_cons = copyMatrix(constants);

    printf("=== Starting Gauss-Seidel Iteration ===\n");
    printf("Original System Matrix:\n");
    printMatrix(copy_eque);
    printf("Constants Vector:\n");
    printMatrix(copy_cons);

    for (size_t i = 0; i < copy_eque.cols; i++)
    {
        bool swapped = true;
        for (size_t j = 0; (j < copy_eque.rows - 1) && (swapped == true); j++)
        {
            swapped = false;
            for (size_t k = j; k < copy_eque.rows - 1 - j; k++)
            {
                if(copy_eque.data[j][k] < copy_eque.data[j][k + 1]){
                    swapRows(copy_eque, k, k + 1);
                    swapRows(copy_cons, k, k + 1);
                    swapped = true;
                    printf("Swapped rows %zu and %zu for diagonal dominance.\n", k, k + 1);
                }
            }
        }
    }
    

    matrices = malloc(sizeof(Matrix) * copy_eque.rows);
    deltas = malloc(sizeof(double) * copy_eque.rows);
    biggers = malloc(sizeof(double) * copy_eque.rows);

    for (size_t i = 0; i < copy_eque.rows; i++)
    {
        // Initialize matrices
        Matrix mat = initMatrix(1, copy_eque.cols);
        for (size_t j = 0; j < copy_eque.cols; j++)
            mat.data[0][j] = copy_eque.data[i][j];

        unsigned *ref;
        matrices[i].data = mat.data;
        ref = &matrices[i].rows;
        *ref = mat.rows;
        ref = &matrices[i].cols;
        *ref = mat.cols;

        // Find the biggest 
        biggers[i] = matrices[i].data[0][i];
    
        matrices[i].data[0][i] = 0;
        scalarMultiply(matrices[i], -1);
        // Initialize solutions
        solutions.data[i][0] = 1;
        
        printf("Row %zu prepared:\n", i);
        printf("  - Isolated variable coefficient: %lf\n", biggers[i]);
        printf("  - Coefficient row after isolation and sign flip:\n");
        printMatrix(matrices[i]);
        printf("  - Initial solution guess: x[%zu] = %lf\n", i, solutions.data[i][0]);
    }
    

    bool condition;
    int iteration = 0;
    do{
        iteration++;
        printf("\n--- Iteration %d ---\n", iteration);
        for (size_t i = 0; i < copy_eque.rows; i++)
        {
            double res = multiply(matrices[i], solutions).data[0][0];
            res += copy_cons.data[i][0];
            res /= biggers[i];
            deltas[i] = fabs(solutions.data[i][0] - res);
            printf("x[%zu]: old = %lf, new = %lf, delta = %lf\n", i, solutions.data[i][0], res, deltas[i]);
            solutions.data[i][0] = res;
        }
        condition = false;
        for (size_t i = 0; (i < copy_eque.rows && condition == false); i++)
            if(deltas[i] > eps)
                condition = true;
        
    }while(condition);
    printf("\n=== Converged after %d iterations ===\n", iteration);
    printf("Final solution vector:\n");
    printMatrix(solutions);

    for (size_t i = 0; i < copy_eque.rows; i++)
    {
        freeMatrix(matrices[i]);
    }
    freeMatrix(copy_eque);
    free(matrices);
    free(deltas);
    free(biggers);
    

    return solutions;
}

#endif

#if !defined(CHOLESKY_H)
#define CHOLESKY_H

Matrix cholesky(const Matrix equations, const Matrix constants, double eps){
    if (equations.rows != equations.cols || equations.rows != constants.rows || constants.cols != 1) {
        printf("Matrix dimension mismatch in cholesky()!\n");
        return (Matrix){.rows = 0, .cols = 0, .data = NULL};
    }

    unsigned n = equations.rows;
    Matrix L = initMatrix(n, n); 
    Matrix y = initMatrix(n, 1);
    Matrix x = initMatrix(n, 1);

    printf("=== Starting Cholesky Decomposition ===\n");
    for (unsigned i = 0; i < n; i++) {
        for (unsigned j = 0; j <= i; j++) {
            double sum = 0.0;
            for (unsigned k = 0; k < j; k++)
                sum += L.data[i][k] * L.data[j][k];

            if (i == j){
                L.data[i][j] = sqrt(fmax(equations.data[i][i] - sum, eps));
                printf("L[%u][%u] (diag) = sqrt(%lf - %lf) = %lf\n", i, j, equations.data[i][i], sum, L.data[i][j]);
            }
            else{
                L.data[i][j] = (1.0 / L.data[j][j]) * (equations.data[i][j] - sum);
                printf("L[%u][%u] = (1 / %lf) * (%lf - %lf) = %lf\n", i, j, L.data[j][j], equations.data[i][j], sum, L.data[i][j]);
            }
        }
    }
    printf("\nLower Triangular Matrix L:\n");
    printMatrix(L);

    // Forward stacking: L * y = b
    for (unsigned i = 0; i < n; i++) {
        double sum = 0.0;
        for (unsigned k = 0; k < i; k++)
            sum += L.data[i][k] * y.data[k][0];
        y.data[i][0] = (constants.data[i][0] - sum) / L.data[i][i];
        printf("y[%u] = (%lf - %lf) / %lf = %lf\n", i, constants.data[i][0], sum, L.data[i][i], y.data[i][0]);
    }

    // Backwards stacking: L^T * x = y
    for (int i = n - 1; i >= 0; i--) {
        double sum = 0.0;
        for (unsigned k = i + 1; k < n; k++)
            sum += L.data[k][i] * x.data[k][0];
        x.data[i][0] = (y.data[i][0] - sum) / L.data[i][i];
        printf("x[%d] = (%lf - %lf) / %lf = %lf\n", i, y.data[i][0], sum, L.data[i][i], x.data[i][0]);
    }
    printf("\n=== Final Solution Vector x ===\n");
    printMatrix(x);
    
    freeMatrix(L);
    freeMatrix(y);
    return x;
}

#endif // CHOLESKY_H

#if !defined(G_DATA_STRUCTURES_H)
#define G_DATA_STRUCTURES_H

typedef enum{
    OP_ERROR = -1,
    OP_FAILURE = 0,
    OP_SUCCESS = 1
} OperationResult;

typedef struct sLLNode{
    const void *data;
    //const DataType type;
    const unsigned element_size;
    struct sLLNode *next;
} *LLNode;

LLNode initNode(unsigned element_size){
    if(element_size == 0){
        printf("An element cannot be of size 0 for initNode()! NULL returned.\n");
        return NULL;
    }
    LLNode node = malloc(sizeof(struct sLLNode));
    unsigned *ref = &node->element_size;
    *ref = element_size;
    node->next = NULL;
    node->data = NULL;
    return node;
}

void freeNode(LLNode *node){
    if(*node == NULL)
        return;
    if((*node)->data != NULL)
        free((*node)->data);
    (*node)->data = NULL;
    (*node)->next = NULL;
    free((*node));
    *node = NULL;
}

void pushNode(LLNode node, void *source){
    if(node == NULL){
        printf("NULL node provided for pushNode()! Ignoring request.\n");
        return;
    }else if(node->data == NULL){
        node->data = malloc(sizeof(node->element_size));
        memcpy(node->data, source, node->element_size);
        node->next = NULL;
    }else{
        while(node->next != NULL)
            node = node->next;
        LLNode new = initNode(node->element_size);
        pushNode(new, source);
        node->next = new;
    }
}

void popNode(LLNode node, void *destination){
    if(node == NULL || node->data == NULL){
        printf("NULL node provided for popNode()! Ignoring request.\n");
    }else if(destination == NULL){
        printf("NULL destination provided for popNode()! Ignoring request.\n");
    }else if(node->next == NULL){ //Only 1 element in the linked list
        memcpy(destination, node->data, node->element_size);
        // Custom free-ing 
        free(node->data);
        node->data = NULL;
        node->next = NULL;
    }else{
        LLNode head = node;
        while(node->next->next != NULL){
            node = node->next;
        }
        memcpy(destination, node->next->data, node->next->element_size);
        free(node->next->data);
        free(node->next);
        node->next = NULL;
    }
}

typedef struct sStack{
    void *data;
    int top;
    const unsigned element_size;
    const unsigned capacity;
} Stack;

Stack initStack(unsigned element_size, unsigned capacity){
    return (Stack){
        .data = malloc(capacity * element_size),
        .top = -1,
        .element_size = element_size,
        .capacity = capacity,
    };
}

void freeStack(Stack *stack){
    if(stack == NULL || stack->data == NULL){
        printf("NULL stack provided for freeStack()! Request ignored.\n");
        return;
    }
    free(stack->data);
    stack->data = NULL;
    unsigned *ref = &stack->capacity;
    *ref = 0;
    ref = &stack->element_size;
    *ref = 0;
}

OperationResult pushStack(Stack *stack, void *source){
    if(stack == NULL || stack->data == NULL){
        #ifdef DEBUG printf("NULL stack provided for pushStack()! Request ignored.\n"); 
        #endif
        return OP_ERROR;
    }else if(source == NULL){
        printf("NULL source provided for pushStack()! Request ignored.\n");
        return OP_ERROR;
    }else if(stack->top >= ((int)stack->capacity - 1)){
        printf("Stack is full for pushStack()! Request ignored.\n");
        return OP_FAILURE;
    }
    char *ptr = (char*)stack->data;// Because char is 1 byte
    memcpy(&ptr[stack->element_size * (++stack->top)], source, stack->element_size);
    return OP_SUCCESS;
}

OperationResult popStack(Stack *stack, void *destination){
    if(stack == NULL || stack->element_size == 0 || stack->data == NULL){
        printf("NULL stack provided for peekStack()! Request ignored.\n");
        return OP_ERROR;
    }
    else if(destination == NULL){
        printf("NULL destination provided for peekStack()! Request ignored.\n");
        return OP_ERROR;
    }
    else if(stack->top < 0){
        printf("Empty stack provided for peekStack()! Request ignored.\n");
        return OP_FAILURE;
    }

    char *ptr = (char*)stack->data;// Because char is 1 byte
    memcpy(destination, &ptr[stack->element_size * stack->top--], stack->element_size);    
    return OP_SUCCESS;
}

OperationResult peekStack(Stack *stack, void *destination){
    if(stack == NULL || stack->element_size == 0 || stack->data == NULL){
        printf("NULL stack provided for popStack()! Request ignored.\n");
        return OP_ERROR;
    }else if(stack->top < 0){
        printf("Empty stack provided for popStack()! Request ignored.\n");
        return OP_FAILURE;
    }

    char *ptr = (char*)stack->data;// Because char is 1 byte
    memcpy(destination, &ptr[stack->element_size * stack->top], stack->element_size);
    return OP_SUCCESS;
}

typedef struct sBinaryTree{
    struct sBinaryTree *parent;

    struct sBinaryTree *left_child;
    struct sBinaryTree *right_child;

    const unsigned element_size;
    void *data;
} *BiTree;

BiTree initTree(const unsigned element_size, void *source){
    if(source == NULL)
        return NULL;
    
    BiTree root = malloc(sizeof(struct sBinaryTree));
    root->left_child = NULL;
    root->right_child = NULL;
    root->parent = NULL;
    unsigned *ptr = &root->element_size;
    *ptr = element_size;
    memcpy(root->data, source, element_size);
    return root;
}

bool isEmptyTree(BiTree tree){
    if(tree == NULL) 
        return true;
    return false;
}

BiTree getLeftTree(BiTree tree){
    if(isEmptyTree(tree))
        return NULL;
    return tree->left_child;
}

BiTree getRightTree(BiTree tree){
    if(isEmptyTree(tree))
        return NULL;
    return tree->right_child;
}

void addLeftTree(BiTree tree, void *source){
    if(isEmptyTree(tree))
        return;

    tree->left_child = initTree(tree->element_size, source);
    tree->left_child->parent = tree;
}

void addRightTree(BiTree tree, void *source){
    if(isEmptyTree(tree))
        return;

    tree->right_child = initTree(tree->element_size, source);
    tree->right_child->parent = tree;
}

void visitTree(BiTree tree){
    if(isEmptyTree(tree) == false) 
        printf("%p ", tree->data);
}
//In-Order Traversal
void lvr(BiTree tree){
    if(isEmptyTree(tree) == false){
        lvr(tree->left_child);
        visitTree(tree);
        lvr(tree->right_child);
    }
}
//In-Order Traversal
void rvl(BiTree tree){
    if(isEmptyTree(tree) == false){
        rvl(tree->right_child);
        visitTree(tree);
        rvl(tree->left_child);
    }
}
//Pre-Order Traversal
void vlr(BiTree tree){
    if(isEmptyTree(tree) == false){
        visitTree(tree);
        vlr(tree->left_child);
        vlr(tree->right_child);
    }
}
//Pre-Order Traversal
void vrl(BiTree tree){
    if(isEmptyTree(tree) == false){
        visitTree(tree);
        vrl(tree->right_child);
        vrl(tree->left_child);
    }
}
//Post-Order Traversal
void lrv(BiTree tree){
    if(isEmptyTree(tree) == false){
        lrv(tree->left_child);
        lrv(tree->right_child);
        visitTree(tree);
    }
}
//Post-Order Traversal
void rlv(BiTree tree){
    if(isEmptyTree(tree) == false){
        rlv(tree->right_child);
        rlv(tree->left_child);
        visitTree(tree);
    }
}

#endif // G_DATA_STRUCTURES_H

#ifndef M_E
#define M_E 2.71828182845904523536
#endif

/* --- Data structures for tokens & RPN --- */
typedef enum {
    T_NUMBER, T_VAR,
    T_PLUS, T_MINUS, T_MUL, T_DIV, T_POW,
    T_LPAREN, T_RPAREN,
    T_FUNC
} TokenType;

typedef struct {
    TokenType type;
    double   value;
    char     func[8];
} Token;

Token *rpn = NULL;
int    rpn_len = 0;

/* --- Stack for tokens --- */
typedef struct { Token *data; int top, cap; } TStack;
void ts_init(TStack *s) { s->cap = 64; s->top = 0; s->data = malloc(s->cap * sizeof *s->data); }
void ts_push(TStack *s, Token t) { if (s->top == s->cap) s->data = realloc(s->data, (s->cap *= 2) * sizeof *s->data); s->data[s->top++] = t; }
Token ts_pop(TStack *s) { return s->data[--s->top]; }
Token ts_peek(TStack *s) { return s->data[s->top - 1]; }
int  ts_empty(TStack *s) { return s->top == 0; }
void ts_free(TStack *s) { free(s->data); }

/* --- Precedence and associativity --- */
int prec(TokenType t) {
    switch (t) {
        case T_PLUS: case T_MINUS: return 1;
        case T_MUL: case T_DIV:    return 2;
        case T_POW:               return 3;
        default:                  return 0;
    }
}
int is_right_assoc(TokenType t) { return t == T_POW; }

/* --- Tokenizer --- */
Token *tokenize(const char *s, int *ntok) {
    Token *out = NULL; int cap = 0, n = 0;
    TokenType last = T_LPAREN;

    #define EMIT(tok) do {                 \
        if (n == cap)                     \
            out = realloc(out, (cap ? cap*2 : 64) * sizeof *out); \
        out[n] = (tok);                   \
        last = out[n].type;               \
        n++;                              \
    } while (0)

    for (int i = 0; s[i]; ) {
        if (isspace((unsigned char)s[i])) { i++; continue; }
        int can_be_signed = (last == T_PLUS || last == T_MINUS || last == T_MUL || last == T_DIV || last == T_POW || last == T_LPAREN);
        // number with optional sign
        if (((s[i] == '+' || s[i] == '-') && can_be_signed && isdigit((unsigned char)s[i+1]))
            || isdigit((unsigned char)s[i])
            || (s[i] == '.' && isdigit((unsigned char)s[i+1]))) {
            char *end;
            double v = strtod(s + i, &end);
            Token t = { .type = T_NUMBER, .value = v };
            EMIT(t);
            i = end - s;
            continue;
        }
        // variable or constant
        if (s[i] == 'x' || s[i] == 'e') {
            Token t = { .type = s[i] == 'x' ? T_VAR : T_NUMBER, .value = s[i] == 'e' ? M_E : 0 };
            EMIT(t);
            i++;
            continue;
        }
        // function name
        if (isalpha((unsigned char)s[i])) {
            char buf[8]; int len = 0;
            while (isalpha((unsigned char)s[i]) && len < 7) buf[len++] = s[i++];
            buf[len] = 0;
            Token t = { .type = T_FUNC };
            strncpy(t.func, buf, sizeof t.func);
            EMIT(t);
            continue;
        }
        // operators and parens
        Token t = {0};
        switch (s[i]) {
            case '+': t.type = T_PLUS;  break;
            case '-': t.type = T_MINUS; break;
            case '*': t.type = T_MUL;   break;
            case '/': t.type = T_DIV;   break;
            case '^': t.type = T_POW;   break;
            case '(': t.type = T_LPAREN;break;
            case ')': t.type = T_RPAREN;break;
            default:
                fprintf(stderr, "Unexpected '%c'\n", s[i]); exit(1);
        }
        EMIT(t);
        i++;

        // implicit multiplication
        if (n > 0) {
            TokenType just = out[n-1].type;
            char next = s[i];
            if ((just == T_NUMBER || just == T_VAR || just == T_RPAREN)
             && (isdigit((unsigned char)next) || next=='x' || next=='e' || next=='(' || isalpha((unsigned char)next))) {
                Token m = { .type = T_MUL };
                EMIT(m);
            }
        }
    }
    *ntok = n;
    return out;
}

/* --- Shunting-Yard → RPN --- */
void to_rpn(Token *in, int nin) {
    TStack st; ts_init(&st);
    free(rpn); rpn = NULL; rpn_len = 0; int cap = 0;
    for (int i = 0; i < nin; i++) {
        Token tok = in[i];
        if (tok.type == T_NUMBER || tok.type == T_VAR) {
            if (rpn_len == cap) rpn = realloc(rpn, (cap ? cap*2 : 64) * sizeof *rpn);
            rpn[rpn_len++] = tok;
        } else if (tok.type == T_FUNC) {
            ts_push(&st, tok);
        } else if (tok.type == T_PLUS || tok.type == T_MINUS || tok.type == T_MUL || tok.type == T_DIV || tok.type == T_POW) {
            while (!ts_empty(&st)) {
                Token top = ts_peek(&st);
                if (top.type == T_FUNC || prec(top.type) > prec(tok.type) || (prec(top.type) == prec(tok.type) && !is_right_assoc(tok.type))) {
                    if (rpn_len == cap) rpn = realloc(rpn, (cap ? cap*2 : 64) * sizeof *rpn);
                    rpn[rpn_len++] = ts_pop(&st);
                } else break;
            }
            ts_push(&st, tok);
        } else if (tok.type == T_LPAREN) {
            ts_push(&st, tok);
        } else if (tok.type == T_RPAREN) {
            while (!ts_empty(&st) && ts_peek(&st).type != T_LPAREN) {
                if (rpn_len == cap) rpn = realloc(rpn, (cap ? cap*2 : 64) * sizeof *rpn);
                rpn[rpn_len++] = ts_pop(&st);
            }
            if (ts_empty(&st)) { fprintf(stderr,"Mismatched parentheses\n"); exit(1); }
            ts_pop(&st);
            if (!ts_empty(&st) && ts_peek(&st).type == T_FUNC) {
                if (rpn_len == cap) rpn = realloc(rpn, (cap ? cap*2 : 64) * sizeof *rpn);
                rpn[rpn_len++] = ts_pop(&st);
            }
        }
    }
    while (!ts_empty(&st)) {
        Token t = ts_pop(&st);
        if (t.type == T_LPAREN || t.type == T_RPAREN) { fprintf(stderr,"Mismatched parentheses\n"); exit(1); }
        if (rpn_len == cap) rpn = realloc(rpn, (cap ? cap*2 : 64) * sizeof *rpn);
        rpn[rpn_len++] = t;
    }
    ts_free(&st);
}

/* --- Evaluate RPN --- */
double eval_rpn(double x) {
    double *stk = malloc(rpn_len * sizeof *stk);
    int sp = 0;
    for (int i = 0; i < rpn_len; i++) {
        Token *t = &rpn[i];
        if (t->type == T_NUMBER) stk[sp++] = t->value;
        else if (t->type == T_VAR) stk[sp++] = x;
        else if (t->type == T_FUNC) {
            if (sp < 1) { fprintf(stderr,"Stack underflow in func\n"); exit(1); }
            double v = stk[--sp], r;
            if (!strcmp(t->func,"sin")) r = sin(v);
            else if (!strcmp(t->func,"cos")) r = cos(v);
            else if (!strcmp(t->func,"tan")) r = tan(v);
            else if (!strcmp(t->func,"exp")) r = exp(v);
            else if (!strcmp(t->func,"log")) r = log(v);
            else if (!strcmp(t->func,"sqrt")) r = sqrt(v);
            else { fprintf(stderr,"Unknown func '%s'\n", t->func); exit(1); }
            stk[sp++] = r;
        } else {
            if (sp < 2) { fprintf(stderr,"Stack underflow in op\n"); exit(1); }
            double b = stk[--sp], a = stk[--sp], r = 0;
            switch (t->type) {
                case T_PLUS:  r = a + b; break;
                case T_MINUS: r = a - b; break;
                case T_MUL:   r = a * b; break;
                case T_DIV:   r = a / b; break;
                case T_POW:   r = pow(a, b); break;
                default: break;
            }
            stk[sp++] = r;
        }
    }
    if (sp != 1) { fprintf(stderr,"RPN eval ended with %d elems\n", sp); exit(1); }
    double out = stk[0]; free(stk);
    return out;
}

/* --- Public API --- */
double _eval(double x) { return eval_rpn(x); }
double (*parse_function(const char *expr))(double) {
    int ntok;
    Token *tokens = tokenize(expr, &ntok);
    to_rpn(tokens, ntok);
    free(tokens);
    return &_eval;
}

/* --- EXAMPLE of how you'd use it: --- */
#ifdef TEST_PARSER
double bisection_meth(double, double, double, double(*)(double));  /* your code */
int main(void){
    char expr[256];
    printf("Enter f(x): ");
    if(!fgets(expr, sizeof expr, stdin)) return 0;
    expr[strcspn(expr,"\n")] = 0;
    double (*f)(double) = parse_function(expr);

    double root = bisection_meth(0, 2, 1e-6, f);
    printf("  → root ~= %.8f\n", root);
    return 0;
}

#endif
// --- these mirror your parser's rpn[] and rpn_len ---
extern Token *rpn;        // declared in parser.c
extern int    rpn_len;    // declared in parser.c

Token *rpn_f = NULL;
int    rpn_len_f;

Token *rpn_fder = NULL;
int    rpn_len_fder;

// copy the parser's current RPN into rpn_f / rpn_fder
void save_current_rpn(Token **dst, int *dst_len) {
    if (*dst) free(*dst);
    *dst_len = rpn_len;
    *dst = malloc(rpn_len * sizeof(Token));
    memcpy(*dst, rpn, rpn_len * sizeof(Token));
}

// swap in a saved RPN before calling eval_rpn()
double call_saved_rpn(Token *src, int src_len, double x) {
    // swap
    Token *old_rpn   = rpn;
    int    old_len   = rpn_len;
    rpn     = src;
    rpn_len = src_len;
    // eval
    double y = eval_rpn(x);
    // restore
    rpn     = old_rpn;
    rpn_len = old_len;
    return y;
}

double call_f(double x) {
    return call_saved_rpn(rpn_f,   rpn_len_f,   x);
}

double call_fder(double x) {
    return call_saved_rpn(rpn_fder, rpn_len_fder, x);
}

/* Helper to compute factorial */
int fact(int n) {
    int res = 1;
    for(int i = 2; i <= n; i++)
        res *= i;
    return res;
}

/* Gregory-Newton Forward Interpolation */
double gregory_newton_interp(double *x, double *y, int n, double x0) {
    double h = x[1] - x[0];  // assume uniform spacing

    // Build forward difference table
    double diff[n][n];
    for(int i = 0; i < n; i++) {
        diff[i][0] = y[i];
        printf("diff[%d][0] = %lf\n", i, diff[i][0]);
    }
    for(int j = 1; j < n; j++) {
        for(int i = 0; i < n - j; i++) {
            diff[i][j] = diff[i+1][j-1] - diff[i][j-1];
            printf("diff[%d][%d] = %lf\n", i, j, diff[i][j]);
        }
    }
    double p = (x0 - x[0]) / h;
    printf("p = %lf\n", p);
    double result = y[0];
    double p_term = 1.0;

    printf("Initial result = %lf\n", result);
    for(int i = 1; i < n; i++) {
        p_term *= (p - (i - 1));
        double term = (p_term * diff[0][i]) / fact(i);
        result += term;
        printf("i=%d, p_term=%lf, diff[0][%d]=%lf, fact(%d)=%d, term=%lf, result=%lf\n", i, p_term, i, diff[0][i], i, fact(i), term, result);
    }

    return result;
}

typedef enum{
    BISECT = 1,
    REGUFA,
    NEWRAP,
    INVERS,
    CHOLSK,
    SEIDAL,
    DERIVE,
    SIMPSO,
    TRAPEZ,
    GRENEW,
    EXIT
} Choice;
int main(){
    printf("Welcome to Ubeyda's Calculator!\n");
    bool running = true;
    while(running){
        printf("1. Solve an equation using the 'Bisection Method'\n");
        printf("2. Solve an equation using the 'Regula-Falsi Method'\n");
        printf("3. Solve an equation using the 'Newton-Raphson Method'\n");
        printf("4. Get inverse of a matrix\n");
        printf("5. Solve a set of equations using the 'Cholesky Method'\n");
        printf("6. Solve a set of equations using the 'Gauss Seidal Method'\n");
        printf("7. Find the derivative of an equation\n");
        printf("8. Find the integral of an equation using 'Simpson Method'(1/3 and 1/8)\n");
        printf("9. Find the integral of an equation using 'Trapezoidal Rule Method'\n");
        printf("10. Interpolate an equation using 'Gregory Newton Method'\n");
        printf("11. Exit\n");
        printf("Make a choice: ");
        Choice input;
        scanf("%i", &input);
        getchar();

        char expr[256];
        char ans[4];    // enough to hold "Y\n\0"
        char cont = 'y';
        double x0, x1;
        char line[64];
        switch (input)
        {
            case BISECT:
                while (cont == 'y' || cont == 'Y') {
                    printf("Enter lower, upper bounds and epsilon (e.g. -10 10 0.001): ");
                    if (!fgets(line, sizeof(line), stdin)) break;
                    double eps;
                    if (sscanf(line, "%lf %lf %lf", &x0, &x1, &eps) != 3) {
                        printf("Invalid input. Using default (-10, 10, 1e-8).\n");
                        x0 = -10; x1 = 10; eps = 1e-8;
                    }
                    // 1) read the function
                    printf("Enter f(x): ");
                    fgets(expr, sizeof(expr), stdin);
                    expr[strcspn(expr, "\n")] = 0; 
                
                    // 2) parse & solve
                    double (*f)(double) = parse_function(expr);
                    double root = bisection_meth(x0, x1, eps, f);
                    if(root != __INT64_MAX__ + 1) printf("x ~= %.8f\n", root);
                
                    // 3) ask to repeat
                    printf("Try another equation? (Y/n): ");
                    fgets(ans, sizeof(ans), stdin);
                    // take first non-whitespace character
                    cont = ans[0];
                    if (cont == '\n' || cont == '\0') 
                        cont = 'y';  // default to 'y' on empty line
                }
                break;
            case REGUFA: 
                while (cont == 'y' || cont == 'Y') {
                    printf("Enter lower, upper bounds and epsilon (e.g. -10 10 0.001): ");
                    if (!fgets(line, sizeof(line), stdin)) break;
                    double eps;
                    if (sscanf(line, "%lf %lf %lf", &x0, &x1, &eps) != 3) {
                        printf("Invalid input. Using default (-10, 10, 1e-8).\n");
                        x0 = -10; x1 = 10; eps = 1e-8;
                    }
                    // 1) read the function
                    printf("Enter f(x): ");
                    fgets(expr, sizeof(expr), stdin);
                    expr[strcspn(expr, "\n")] = 0; 
                
                    // 2) parse & solve
                    double (*f)(double) = parse_function(expr);
                    double root = regula_falsi(x0, x1, eps, f);
                    if(root != __INT64_MAX__ + 1) printf("x ~= %.8f\n", root);
                
                    // 3) ask to repeat
                    printf("Try another equation? (Y/n): ");
                    fgets(ans, sizeof(ans), stdin);
                    // take first non-whitespace character
                    cont = ans[0];
                    if (cont == '\n' || cont == '\0') 
                        cont = 'y';  // default to 'y' on empty line
                }
                break;
            case NEWRAP:
                {
                    char buf[256];
                    const double eps = 1e-8;
                    double x0;
                    while (cont == 'y' || cont == 'Y') {
                        // 1) get the starting guess
                        printf("Enter initial guess x0 and epsilon (3.4 0.001): ");
                        fgets(buf, sizeof(buf), stdin);
                        sscanf(buf, "%lf %lf", &x0, &eps);
                        
                        // 2) read & save f(x)
                        printf("Enter f(x): ");
                        fgets(buf, sizeof(buf), stdin);
                        buf[strcspn(buf, "\n")] = 0;
                        parse_function(buf);            // builds rpn[] for f
                        save_current_rpn(&rpn_f, &rpn_len_f);
                        
                        // 3) read & save f'(x)
                        printf("Enter f'(x): ");
                        fgets(buf, sizeof(buf), stdin);
                        buf[strcspn(buf, "\n")] = 0;
                        parse_function(buf);            // rebuilds rpn[] for f′
                        save_current_rpn(&rpn_fder, &rpn_len_fder);
                        
                        // 4) call Newton–Raphson with our wrappers
                        double root = newton_raphton(x0, eps, call_f, call_fder);
                        if (root != __INT64_MAX__ + 1)
                            printf("x ~= %.8f\n", root);
                        // 3) ask to repeat
                        printf("Try another equation? (Y/n): ");
                        fgets(ans, sizeof(ans), stdin);
                        // take first non-whitespace character
                        cont = ans[0];
                        if (cont == '\n' || cont == '\0') 
                            cont = 'y';  // default to 'y' on empty line
                    }
                }
                break;
                
                case INVERS:
                    while (cont == 'y' || cont == 'Y') {
                        
                        // Inverse of an n×n matrix
                        char line[64];
                        printf("Enter matrix size n: ");
                        fgets(line, sizeof(line), stdin);
                        int n = atoi(line);
                    
                        Matrix A = initMatrix(n, n);
                        double flat[n * n];
                        printf("Enter %dx%d entries row-by-row.\n", n, n);
                        for (int i = 0; i < n; i++) {
                            fgets(line, sizeof(line), stdin);
                            char *p = line;
                            for (int j = 0; j < n; j++) {
                                flat[i*n + j] = strtod(p, &p);
                            }
                        }
                        // now populate the Matrix in one go
                        setDataMatrix(A, flat);
                    
                        Matrix Ainv = inverse(A);
                        printf("Inverse matrix:\n");
                        printMatrix(Ainv);
                    
                        freeMatrix(A);
                        freeMatrix(Ainv);
                        printf("Try another matrix? (Y/n): ");
                        fgets(ans, sizeof(ans), stdin);
                        // take first non-whitespace character
                        cont = ans[0];
                        if (cont == '\n' || cont == '\0') 
                            cont = 'y';  // default to 'y' on empty line
                    }
                break;

            case CHOLSK:
                while (cont=='y'||cont=='Y'){
                    //printf("Enter size n and then %dx%dx1 constant vector:\n");
                    // read n and constants and matrix then:
                    printf("Enter matrix size n: ");
                    fgets(line, sizeof(line), stdin);
                    int m = atoi(line);
                    Matrix A = initMatrix(m,m);
                    Matrix bvec = initMatrix(m,1);
                    double temp;
                    for(int i=0;i<m;i++){
                        printf("Enter A's %ith row (a b ...):", i+1);
                        fgets(line,sizeof(line),stdin);
                        char* p=line;
                        for(int j=0;j<m;j++){
                            A.data[i][j]=strtod(p,&p);
                        }
                    }
                    bool is_symmetric = true;
                    for(int i=0;i<m;i++)
                      for(int j=0;j<m;j++)
                        if (fabs(A.data[i][j] - A.data[j][i]) > 1e-12)
                          is_symmetric = false;
                    if (!is_symmetric) {
                      printf("Error: matrix must be symmetric positive-definite for Cholesky.\n");
                    }else{
                        for (int i = 0; i < m; i++)
                        {
                            printf("Enter B's %ith row (a): ", i+1);
                            double read;
                            scanf("%lf", &read);
                            bvec.data[i][0]=read;
                        }
                        Matrix x = cholesky(A,bvec,1e-8);
                        printf("Solution vector x:\n");
                        printMatrix(x);
                        freeMatrix(A); freeMatrix(bvec); freeMatrix(x);
                        }
                    getc(stdin);
                    printf("Try another? (Y/n): "); fgets(ans,sizeof(ans),stdin);
                    cont=ans[0]==0?'y':ans[0];
                }
                break;
            case SEIDAL:
                while(cont=='y'||cont=='Y'){
                    int m;
                    printf("Enter matrix size n: ");
                    scanf("%i", &m);
                    Matrix A=initMatrix(m,m);
                    Matrix bvec=initMatrix(m,1);
                    getc(stdin);
                    printf("NOTE: Make sure to enter a symmetrical matrix.[ Otherwise you'll have some ASCII fireworks :) ]\n");
                    for(int i=0;i<m;i++){
                        printf("Enter A's %ith row (a b ...):", i+1);
                        fgets(line,sizeof(line),stdin);
                        char* p = line;
                        for(int j=0;j<m;j++) 
                            A.data[i][j]=strtod(p,&p);
                    }
                    for (int i = 0; i < m; i++)
                    {
                        printf("Enter B's %ith row (a): ", i+1);
                        double read;
                        scanf("%lf", &read);
                        bvec.data[i][0]=read;
                    }
                    
                    Matrix sol = gauss_seidal(A,bvec,1e-8);
                    printf("Solution vector x:\n"); printMatrix(sol);
                    freeMatrix(A); freeMatrix(bvec); freeMatrix(sol);
                    getc(stdin);
                    printf("Try another? (Y/n): "); fgets(ans,sizeof(ans),stdin);
                    cont=ans[0]==0?'y':ans[0];
                }
                break;
            case DERIVE:
                while(cont=='y'||cont=='Y'){
                    printf("Enter function f(x): ");
                    double a, b;
                    fgets(expr,sizeof(expr),stdin); expr[strcspn(expr,"\n")]=0;
                    double (*f)(double)=parse_function(expr);
                    printf("\n");
                    printf("Enter point x0 and epsilon (3.14 0.001): ");
                    fgets(line,sizeof(line),stdin); sscanf(line,"%lf %lf",&x0,&a);
                    double d_central = central_diff_derivative(x0,a,f);
                    double d_back = back_diff_derivative(x0,a,f);
                    double d_front = front_diff_derivative(x0,a,f);
                    printf("Back f'(%.4f) ~= %.8f\n", x0, d_back);
                    printf("Central f'(%.4f) ~= %.8f\n", x0, d_central);
                    printf("Front f'(%.4f) ~= %.8f\n", x0, d_front);
                    printf("Try another? (Y/n): "); fgets(ans,sizeof(ans),stdin);
                    cont=ans[0]==0?'y':ans[0];
                }
                break;

            case SIMPSO:
                while(cont=='y'||cont=='Y'){
                    double a, b;
                    unsigned n;
                    printf("Enter a - b interval (a b): ");
                    scanf("%lf %lf", &a, &b);
                    printf("Enter number of trapezoids (n): ");
                    scanf("%u", &n);
                    getc(stdin);
                    printf("Enter function f(x): "); fgets(expr,sizeof(expr),stdin); expr[strcspn(expr,"\n")]=0;
                    double (*f2)(double)=parse_function(expr);
                    double res1 = simpson_1_3_integration(a,b,n,f2);
                    printf("Simpson 1/3 result: %.8f\n", res1);
                    double res2 = simpson_3_8_integration(a,b,n,f2);
                    printf("Simpson 3/8 result: %.8f\n", res2);
                    printf("Try another? (Y/n): "); fgets(ans,sizeof(ans),stdin);
                    cont=ans[0]==0?'y':ans[0];
                }
                break;

            case TRAPEZ:
                while(cont=='y'||cont=='Y'){
                    double a, b;
                    unsigned n;
                    printf("Enter a - b interval (a b): ");
                    scanf("%lf %lf", &a, &b);
                    printf("Enter number of trapezoids (n): ");
                    scanf("%u", &n);
                    //fgets(line,sizeof(line),stdin); sscanf(line,"%lf %lf %u",&a,&b,&n);
                    getc(stdin);
                    printf("Enter function f(x): "); fgets(expr,sizeof(expr),stdin); expr[strcspn(expr,"\n")]=0;
                    double (*f3)(double)=parse_function(expr);
                    double res = trapezoidal_integration(a,b,n,f3);
                    printf("Trapezoidal result: %.8f\n", res);
                    printf("Try another? (Y/n): "); fgets(ans,sizeof(ans),stdin);
                    cont=ans[0]==0?'y':ans[0];
                }
                break;
            case GRENEW: 
                while(cont == 'y' || cont == 'Y'){                
                    int n;
                    printf("Enter number of data points: ");
                    scanf("%d", &n);
                    
                    double x[n], y[n];
                    printf("Enter x values:\n");
                    for(int i = 0; i < n; i++){
                        printf("%i. x: ", i+1);
                        scanf("%lf", &x[i]);
                    }
                    printf("Enter y values:\n");
                    for(int i = 0; i < n; i++){ 
                        printf("%i. y: ", i+1);
                        scanf("%lf", &y[i]);
                    }
                    
                    double x0;
                    printf("Enter x0 to interpolate: ");
                    scanf("%lf", &x0);
                    
                    double y0 = gregory_newton_interp(x, y, n, x0);
                    printf("Interpolated value at x = %.4f is %.8f\n", x0, y0);
                    printf("Try another? (Y/n): "); scanf(" %c", ans);
                    cont=ans[0]==0?'y':ans[0];
                }
                break;
            case EXIT:
                running = false;
                break;
            default:
                printf("Unknown input!\n");
                break;
        }
    }
    

    
    return 0;
}
